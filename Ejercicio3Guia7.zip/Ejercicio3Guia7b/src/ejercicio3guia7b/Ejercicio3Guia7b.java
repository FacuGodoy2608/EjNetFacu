/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3guia7b;

import Operacion.Operacion;

/**
 *
 * @author Martin
 */
public class Ejercicio3Guia7b {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Operacion calculos = new Operacion();//llama la clase Operacion
       calculos.ingresarnro();
        System.out.println("La suma es: " + calculos.Sumar());
        System.out.println("La resta es: " + calculos.Restar());
        System.out.println("La multiplicacion es: " + calculos.Multiplicar());   
        System.out.println("La division es: " + calculos.Dividir());
                
    }
    
}
